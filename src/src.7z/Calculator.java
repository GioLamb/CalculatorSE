import java.util.Scanner;

public class Calculator {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Welcome to the Calculator!");

        while (true) {
            System.out.println("Choose an operation:");
            System.out.println("+ for Addition");
            System.out.println("- for Subtraction");
            System.out.println("* for Multiplication");
            System.out.println("/ for Division");
            System.out.println("Q to Quit");
            System.out.print("Enter your choice: ");

            String choice = scanner.next();

            if (choice.equalsIgnoreCase("Q")) {
                System.out.println("Goodbye!");
                break;
            }

            System.out.print("Enter the number of values: ");
            int count = scanner.nextInt();
            double[] numbers = new double[count];

            for (int i = 0; i < count; i++) {
                System.out.print("Enter number " + (i + 1) + ": ");
                numbers[i] = scanner.nextDouble();
            }

            double result = 0;
            String operator = "";

            switch (choice) {
                case "+":
                    result = Sum.add(numbers);
                    operator = "+";
                    break;
                case "*":
                    result = Multiply.multiply(numbers);
                    operator = "*";
                    break;
                case "/":
                    result = Division.divide(numbers);
                    operator = "/";
                    break;
                default:
                    System.out.println("Invalid choice.");
                    continue;
            }

            System.out.print("Result: ");
            for (int i = 0; i < count; i++) {
                System.out.print(numbers[i]);
                if (i < count - 1) {
                    System.out.print(" " + operator + " ");
                }
            }
            System.out.println(" = " + result);
        }

        scanner.close();
    }
}
